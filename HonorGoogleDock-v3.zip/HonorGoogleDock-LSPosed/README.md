# HonorGoogleDock-LSPosed v3

Experimental LSPosed module targeting the uploaded Honor Launcher APK version 16.0.20.221 (`com.hihonor.android.launcher`).

## What changed in v3
- Uses the confirmed Honor launcher class `com.hihonor.android.launcher.Launcher` rather than also trying generic Launcher3 class candidates.
- Hooks `onResume` to create/restore the Google-style search overlay.
- Hooks the launcher's `enterEditMode`, `exitEditMode`, and related exit methods when present. This replaces the fragile visible-text scan that could leave the search bar hidden on the normal home screen.
- Tries to move actual View instances whose class names include `Hotseat` or `Dock` upward by 66dp. The APK contains `com.hihonor.android.launcher.hotseat.HotseatManager`, `HotseatImpl`, and related classes, but a manager class is not necessarily a View; logs report any actual View that gets shifted.
- The search bar is positioned 8dp above the bottom edge.

## Build
Upload the contents of this folder to a GitHub repository root and run the included GitHub Actions workflow. Download the `HonorGoogleDock-LSPosed-debug` artifact.

## Install / test
1. Install the newly built APK. If updating fails, uninstall the old module APK first (this does not remove launcher data).
2. Enable the module in LSPosed and scope it to `com.hihonor.android.launcher`.
3. Force-stop Honor Launcher or reboot.
4. Check LSPosed logs for `HonorGoogleDock` messages. In particular, look for `hooked Launcher.enterEditMode`, `hooked Launcher.exitEditMode`, and `shifted view ...`.

## Limitations
This is still an overlay-based prototype, not a native insertion into Honor's layout. If no actual Hotseat/Dock View is found in the runtime hierarchy, the module cannot reserve space for the bar and icons may overlap. In that case the logs are needed to identify the real view hierarchy and the correct layout method. The project has not been built or device-tested in this environment.
